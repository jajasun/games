// ============================================================================
//! @file   Texture.cpp
//! @brief  �e�N�X�`���N���X����
//! @date   2016-04-18
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================

#include <WICTextureLoader.h>
#include "Texture.h"
#include "Direct3D.h"
#include "DirectXTK.h"

using namespace DirectX::SimpleMath;
using namespace DirectX;

// ============================================================================
//! @brief �R���X�g���N�^
//! @param[in] file_path �ǂݍ��ރt�@�C���p�X
// ============================================================================
Texture::Texture(const wchar_t* file_path) 
{
	DirectX::CreateWICTextureFromFile(g_pd3dDevice.Get(), file_path, &resource_, &texture_);
	static_cast<ID3D11Texture2D*>(resource_)->GetDesc(&desc_);
	float w = static_cast<float>(desc_.Width / 2);
	float h = static_cast<float>(desc_.Height / 2);

	center_ = Vector2(w, h);
}

// ============================================================================
//! @brief �f�X�g���N�^
// ============================================================================
Texture::~Texture() 
{
	texture_->Release();
	resource_->Release();
}

// ============================================================================
//! @brief �e�N�X�`���`��
//! @param[in] position �`����W
//! @return �Ȃ�
// ============================================================================
void Texture::Draw(const Vector2& position) const 
{
	g_spriteBatch->Draw(texture_, position, nullptr, Colors::White, 0.0f, center_);
}
// ============================================================================
//! @brief �e�N�X�`���`��
//! @param[in] position �`����W
//! @param[in] angle ��]�p�x(rad)
//! @return �Ȃ�
// ============================================================================
void Texture::Draw(const Vector2& position, float angle) const 
{
	RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = desc_.Width;
	rect.bottom = desc_.Height;

	g_spriteBatch->Draw(texture_, position, &rect, Colors::White, angle, center_);
}

// ============================================================================
//! @brief �e�N�X�`���`��
//! @param[in] position �`����W
//! @param[in] angle ��]�p�x(rad)
//! @param[in] scale �g�嗦
//! @return �Ȃ�
// ============================================================================
void Texture::Draw(const Vector2& position, float angle, float scale) const 
{
	RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = desc_.Width;
	rect.bottom = desc_.Height;

	g_spriteBatch->Draw(texture_, position, &rect, Colors::White, angle, center_, scale);
}

// ============================================================================
//! @brief �e�N�X�`���`��
//! @param[in] position �`����W
//! @param[in] angle ��]�p�x(rad)
//! @param[in] scale �g�嗦(x, y�ʎw��)
//! @return �Ȃ�
// ============================================================================
void Texture::Draw(const Vector2& position, float angle, const Vector2& scale) const 
{
	RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = desc_.Width;
	rect.bottom = desc_.Height;

	g_spriteBatch->Draw(texture_, position, &rect, Colors::White, angle, center_, scale);
}

// ============================================================================
//! @brief �e�N�X�`���`��
//! @param[in] position �`����W
//! @param[in] angle ��]�p�x(rad)
//! @param[in] origine ���S���W
//! @param[in] scale �g�嗦(x, y�ʎw��)
//! @return �Ȃ�
// ============================================================================
void Texture::Draw(const Vector2& position, float angle, const Vector2& origine, const Vector2& scale) const 
{
	RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = desc_.Width;
	rect.bottom = desc_.Height;

	g_spriteBatch->Draw(texture_, position, &rect, Colors::White, angle, origine, scale);
}

// ============================================================================
//! @brief �e�N�X�`���`��
//! @param[in] position �`����W
//! @param[in] src_position �`�悷��e�N�X�`���̕`�悵������`�̍�����W
//! @param[in] src_size �`�悵������`�̃T�C�Y
//! @return �Ȃ�
// ============================================================================
void Texture::Draw(const Vector2& position, const Vector2& src_position, const Vector2& src_size) const 
{
	RECT rect;
	rect.left = static_cast<int>(src_position.x);
	rect.top = static_cast<int>(src_position.y);
	rect.right = static_cast<int>(src_position.x + src_size.x);
	rect.bottom = static_cast<int>(src_position.y + src_size.y);

	g_spriteBatch->Draw(texture_, position, &rect, Colors::White);
}

// ============================================================================
//! @brief �e�N�X�`���`��
//! @param[in] position �`����W
//! @param[in] angle ��]�p�x(rad)
//! @param[in] origine ���S���W
//! @param[in] scale �g�嗦
//! @return �Ȃ�
// ============================================================================
void Texture::Draw(const Vector2& position, float angle, const Vector2& origine, float scale) const 
{
	RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = desc_.Width;
	rect.bottom = desc_.Height;

	g_spriteBatch->Draw(texture_, position, &rect, Colors::White, angle, origine, scale);
}

// ============================================================================
//! @brief �e�N�X�`���`��
//! @param[in] position �`����W
//! @param[in] src_position �`�悷��e�N�X�`���̕`�悵������`�̍�����W
//! @param[in] src_size �`�悵������`�̃T�C�Y
//! @param[in] angle ��]�p�x(rad)
//! @param[in] scale �g�嗦
//! @return �Ȃ�
// ============================================================================
void Texture::Draw(const Vector2& position, const Vector2& src_position, const Vector2& src_size,
	float angle, float scale) const 
{
	RECT rect;
	rect.left = static_cast<int>(src_position.x);
	rect.top = static_cast<int>(src_position.y);
	rect.right = static_cast<int>(src_position.x + src_size.x);
	rect.bottom = static_cast<int>(src_position.y + src_size.y);

	g_spriteBatch->Draw(texture_, position, &rect, Colors::White, angle, Vector2(0, 0), scale);
}
