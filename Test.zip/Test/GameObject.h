#pragma once
class GameObject
{
public:
	GameObject();
	~GameObject();
};

