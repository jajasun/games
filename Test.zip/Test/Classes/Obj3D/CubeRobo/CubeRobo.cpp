// ============================================================================
//! @file	CubuRobo.cpp  
//! @brief  
//! @date   
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#include "CubeRobo.h"
#include "../../../DirectXTK.h"
using namespace DirectX;
using namespace DirectX::SimpleMath;

// ============================================================================
//! @brief �R���X�g���N�^ 
// ============================================================================
CubeRobo::CubeRobo()
	:_init(false)
{
	
}

// ============================================================================
//! @brief �f�X�g���N�^ 
// ============================================================================
CubeRobo::~CubeRobo()
{
}

// ============================================================================
//! @brief ������ 
// ============================================================================
bool CubeRobo::Initialize()
{
	// ���{�b�g�̃��f���ǂݍ���
	// ��
	_obj[PARTS_HEAD].LoadModelFile(L"cModels/Player1.cmo");
	// �E�r
	_obj[PARTS_RIGHT_ARM].LoadModelFile(L"cModels/Player1.cmo");
	_obj[PARTS_RIGHT_ARM].SetParentMatrix(&_obj[PARTS_HEAD].GetLocalWorld());
	_obj[PARTS_RIGHT_ARM].SetTrans(Vector3(1, 0, 0));
	_obj[PARTS_RIGHT_ARM].SetScale(Vector3(0.5f, 0.5f, 0.5f));
	// ���r
	_obj[PARTS_LEFT_ARM].LoadModelFile(L"cModels/Player1.cmo");
	_obj[PARTS_LEFT_ARM].SetParentMatrix(&_obj[PARTS_HEAD].GetLocalWorld());
	_obj[PARTS_LEFT_ARM].SetTrans(Vector3(-1, 0, 0));
	_obj[PARTS_LEFT_ARM].SetScale(Vector3(0.5f, 0.5f, 0.5f));

	_init = true;
	return _init;
}

// ============================================================================
//! @brief �X�V 
// ============================================================================
void CubeRobo::Update()
{

	if (!_init)
		Initialize();

	Vector3 moveV;
	if (g_key.W) 
	{ 
		// �ړ��x�N�g��(Z���W�O�i)
		moveV += Vector3(0, 0, -1);
	}
	if (g_key.A) 
	{
		// �ړ��x�N�g��(Z���W�O�i)
		moveV += Vector3(-1, 0, 0);
	}
	if (g_key.S) 
	{
		// �ړ��x�N�g��(Z���W�O�i)
		moveV += Vector3(0, 0, 1);
	}
	if (g_key.D) 
	{
		// �ړ��x�N�g��(Z���W�O�i)
		moveV += Vector3(1, 0, 0);
	}





	// ���݂̍��W�E��]�p���擾
	Vector3 trans = _obj[PARTS_HEAD].GetTrans();
	Vector3 _rot = _obj[PARTS_HEAD].GetRot();
	Matrix rotz = Matrix::CreateRotationZ(_rot.z);
	Matrix roty = Matrix::CreateRotationY(_rot.y);
	Matrix rotx = Matrix::CreateRotationX(_rot.x);
	Matrix rotmatrix = rotx *  roty * rotz;
	// �ړ��x�N�g������]����
	moveV = Vector3::TransformNormal(moveV, rotmatrix);
	// �ړ�
	moveV.Normalize();
	moveV *= 0.1f;
	trans += moveV;
	// �ړ��������W�𔽉f
	_obj[PARTS_HEAD].SetTrans(trans);



	for (int i = 0; i < PARTS_NUM; i++)
	{
		_obj[i].Calc();
	}
}

// ============================================================================
//! @brief �`�� 
// ============================================================================
void CubeRobo::Draw() const
{
	// �S�p�[�c���`��
	for (int i = 0; i < PARTS_NUM; i++)
	{
		_obj[i].Draw();
	}
}

