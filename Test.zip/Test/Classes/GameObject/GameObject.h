// ============================================================================
//! @file	GameObject.h  
//! @brief  �Q�[���I�u�W�F�N�g
//! @date   
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once
#include <SimpleMath.h>

// ============================================================================
//! @brief	�N���X�錾 
// ============================================================================

// ============================================================================
//! @class	GameObject
//! @brief	�Q�[�����ɑ��݂���I�u�W�F�N�g
// ============================================================================
class GameObject
{
protected:
	// �ʒu
	DirectX::SimpleMath::Vector3 _position;
public:
	// �ʒu���Z�b�g
	DirectX::SimpleMath::Vector3 setPosition(DirectX::SimpleMath::Vector3& position) { _position = position; }
	// ���݈ʒu���擾
	DirectX::SimpleMath::Vector3 getPosition() { return _position; }
	// �R���X�g���N�^
	GameObject(); 
	GameObject(DirectX::SimpleMath::Vector3 position);
	~GameObject();
};