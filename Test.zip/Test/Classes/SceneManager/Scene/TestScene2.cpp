#include "TestScene2.h"
#include "../../GameManger/GameManager.h"
#include "../SceneManager.h"
#include "../../../DirectXTK.h"
#include "TestScene.h"
#include "../../../Direct3D.h"

TestScene2::TestScene2()
{
	_sceneManager = SceneManager::getInstance();
}


TestScene2::~TestScene2()
{

}

bool TestScene2::Initialize()
{
	return false;
}

void TestScene2::Update()
{


}

void TestScene2::Draw() const
{

	
	if (g_keyTracker->IsKeyPressed(DirectX::Keyboard::C))
	{
		GameManager* gameManager = GameManager::getInstance();
		Scene* scene = new TestScene;
		gameManager->setNextScene(scene);
	}

}
