// ============================================================================
//! @file   Scene.h
//! @brief  �V�[���֘A�̃w�b�_�t�@�C��
//! @date   2016-04-18
//! @author
//  Copyright (C) 2016 . All rights reserved.
// ============================================================================
#pragma once
#include "..\..\Interface\Interface.h"
// ============================================================================
//! @brief �V�[���N���X
//!
//! �e�V�[���͂��̃N���X���p������
// ============================================================================
class SceneManager;
class TextureManager;
class Scene:public IRunner
{
protected:
	bool _init;
	SceneManager* _sceneManager;
	TextureManager* _textureManager;
public:
    Scene();
    virtual ~Scene();

	virtual bool Initialize()  = 0;
	virtual void Update()override = 0;
    virtual void Draw() const override = 0;
};

