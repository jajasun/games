#pragma once
#include "Scene.h"
#include "../../Camera/Camera.h"
class TestScene2 :
	public Scene
{
private :
	Camera* _camera;
public:
	TestScene2();
	~TestScene2();

	bool Initialize() override;
	void Update() override;
	void Draw() const override;

};

