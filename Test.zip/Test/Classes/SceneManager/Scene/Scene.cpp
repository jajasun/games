// ============================================================================
//! @file   Scene.cpp
//! @brief  �V�[���N���X����
//! @date   2016-04-18
//! @author 
//  Copyright (C) 2016 . All rights reserved.
// ============================================================================
#include "Scene.h"

Scene::Scene()
	:_init(false),_sceneManager(nullptr),_textureManager(nullptr)
{
}

Scene::~Scene()
{
}
