// ============================================================================
//! @file   TestScene
//! @brief  �e�X�g�p�V�[��
//! @date   
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once
#include "Scene.h"
#include "../../../Direct3D.h"
#include "../../../DirectXTK.h"
#include "../../../DebugCamera.h"
#include "../../Camera/Camera.h"
#include "../../Obj3D/Obj3D.h"
#include <wrl.h>
#include <d3d11.h>
#include <Model.h>
#include <SimpleMath.h>
#include <Effects.h>
#include <DirectXColors.h>
#include <memory>
#include "../../Obj3D/CubeRobo/CubeRobo.h"
// ============================================================================
//! @brief	�N���X�錾 
// ============================================================================
class GameManager;


extern HWND g_hWnd;

// ============================================================================
//! @class	TestScene
//! @brief	�e�X�g�V�[���N���X
// ============================================================================
class TestScene :
	public Scene
{
private:
	std::unique_ptr<DirectX::Model> _model;
	std::unique_ptr<DirectX::DGSLEffectFactory> _fxFactory;
	std::unique_ptr<DirectX::CommonStates> _commonStates;
	GameManager* _gameManager;
	DebugCamera* _debugCamera;
	Camera* _camera;
	DirectX::SimpleMath::Vector3 _lightDir;
	float _timeCount;
	bool _debug;
	CubeRobo* _cubeRobo;

	DirectX::Mouse* _mouse;
public:
	TestScene();
	~TestScene();

	bool Initialize() override;
	void Update() override;
	void Draw()const override;


};

