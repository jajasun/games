// ============================================================================
//! @file   TestScene.cpp
//! @brief  �e�X�g�V�[��
//! @date   
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#define _OX_EPSILON_ 0.000001f // �덷
#include "../Scene/TestScene.h"
#include "../SceneManager.h"
#include "../../TextureManager/TextureManager.h"
#include "../../GameManger/GameManager.h"
#include "TestScene2.h"
#include "../../../Grid.h"
#include "../../GameObject/GameObject.h"
#include "../../Collider/FlexibleCollision.h"
using namespace std;
using namespace DirectX;
using namespace DirectX::SimpleMath;
// ============================================================================
//! @brief	�R���X�g���N�^
// ============================================================================
TestScene::TestScene()
{
	_init = false;
	_sceneManager = SceneManager::getInstance();
	_textureManager = TextureManager::getInstance();
	_gameManager = GameManager::getInstance();
	_debugCamera = new DebugCamera(_gameManager->_WindowSize_W, _gameManager->_WindowSize_H);
	_camera = new Camera();
	_cubeRobo = new CubeRobo;

}

// ============================================================================
//! @brief	�f�X�g���N�^
// ============================================================================
TestScene::~TestScene()
{
}

// ============================================================================
//! @brief	������
// ============================================================================
bool TestScene::Initialize()
{
	//�G�t�F�N�g�t�@�N�g���̍쐬
	_fxFactory.reset(new DGSLEffectFactory(g_pd3dDevice.Get()));
	//�e�N�X�`���̓ǂݍ��݃p�X���w��			�e�N�X�`���̃p�X���w��
	_fxFactory->SetDirectory(L"cModels");
	////�t�@�C�����w�肵�ă��f���f�[�^��ǂݍ���	���f���̃p�X���w��
	_model = Model::CreateFromCMO(
		g_pd3dDevice.Get(),
		L"cModels\\stage.cmo", *_fxFactory.get());

	// �`��p�R�����X�e�[�g���쐬
	_commonStates.reset(new CommonStates(g_pd3dDevice.Get()));


	_timeCount = 0.0f;

	_camera->SetEyepos(Vector3(0, 30, -40));

	// ============================================================================
	//! @brief Obj3D������ 
	// ============================================================================
	{
		//�ÓI�����o�֐�
		//�f�o�C�X�̐ݒ�
		Obj3D::SetDevice(g_pd3dDevice.Get());
		//�f�o�C�X�R���e�L�X�g�̐ݒ�
		Obj3D::SetDeviceContext(g_pImmediateContext.Get());
		//�`��X�e�[�g�̐ݒ�
		Obj3D::SetStates(g_state.get());
		//�G�t�F�N�g�t�@�N�g���̐ݒ�
		Obj3D::SetEffectFactory(_fxFactory.get());
		//�J�����̐ݒ�
		Obj3D::SetCamera(_camera);

		Matrix world = Matrix::Identity;
		_cubeRobo->Initialize();

	}


	



	_debug = false;
	_init = true;
	return _init ;
}

// ============================================================================
//! @brief	�X�V
// ============================================================================
void TestScene::Update()
{
	if (!_init)
		Initialize();

	_timeCount += 1.0f / 60.0f;
	_model->UpdateEffects([&](IEffect* effect) {
		if (auto e = dynamic_cast<DGSLEffect*>(effect))
		{
			e->SetLightDirection(0,_lightDir);
			e->SetTime(_timeCount);
		}
	});
	_cubeRobo->Update();

	Matrix world = _cubeRobo->GetLocalWorld(CubeRobo::PARTS_HEAD);
	
	// �J�����̐ݒ�
	Vector3 eye = Vector3::Transform(Vector3(0, 5, 10), world);
	Vector3 at = Vector3::Transform(Vector3::Zero, world);
	eye += at;
	Vector3 up = Vector3(0, 1, 0);
	_camera->SetEyepos(eye);
	_camera->SetRefpos(at);
	_camera->SetUpvec(up);
	
	if (g_keyTracker->IsKeyPressed(Keyboard::P))
	{
		_debug = _debug ? false : true;
	}
	if (_debug)
	{
		Obj3D::SetCamera(_debugCamera);
		_debugCamera->Update(); 	_lightDir = Vector3(0, -10, -10);
	}
	else
	{
		Obj3D::SetCamera(_camera);
		_camera->Update();			_lightDir = Vector3(0, -10, 0);
	}

	if (g_keyTracker->IsKeyPressed(Keyboard::C))
	{
		_gameManager->setNextScene(new TestScene2);
	}

}

// ============================================================================
//! @brief	�`��
// ============================================================================
void TestScene::Draw() const
{
	Matrix world = Matrix::Identity;
	world = Matrix::CreateRotationY(_timeCount);

	Matrix view;
	Matrix proj;

	if (_debug)
	{
		view = _debugCamera->GetCameraMatrix();
		proj = Matrix::CreatePerspectiveFieldOfView(XMConvertToRadians(45.0f), _gameManager->_WindowSize_W / (float)_gameManager->_WindowSize_H, 1.0f, 1000.0f);
	}
	else
	{
		view = _camera->GetViewmat();
		proj = _camera->GetProjmat();
	}

	// �O���b�h���I�u�W�F�N�g
	GridFloor gridFloor(20.0f, 20);
	gridFloor.Render(view, proj);

	//_model->Draw(g_pImmediateContext.Get(), *g_state.get(), world, view, proj);
	_cubeRobo->Draw();



}
