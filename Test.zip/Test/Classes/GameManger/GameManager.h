// ============================================================================
//! @file	GameManager.h
//! @brief	�Q�[�����Ǘ�����N���X�w�b�_�[
//! @date   
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once
#include "../Interface/Interface.h"
#include <memory>
#include <vector>
#include <algorithm>
#include <SimpleMath.h>

// ============================================================================
//! @brief �N���X�錾
// ============================================================================
class SceneManager;
class Scene;
class Object;

// ============================================================================
//! @class	GameManager
//! @brief	�Q�[���}�l�[�W���[�̃V���O���g���N���X
// ============================================================================
class GameManager
	:public IRunner
{
private:
	static GameManager* _instance;
	SceneManager* _sceneManager;
	int _DebugScore;
	Scene* _nextscene;
public:
	// �E�B���h�E�T�C�Y
	const int _WindowSize_W = 1280;
	const int _WindowSize_H = 720;

	static GameManager* getInstance();
	GameManager();
	~GameManager();

	bool Initialize() override;
	void Update() override;
	void Draw()const override;
	
	void AddScore(int score);
	int GetScore();

	void setView(DirectX::SimpleMath::Matrix view) { _view = view; }
	void setProj(DirectX::SimpleMath::Matrix proj) { _proj = proj; }


	Scene* getNextScene() { return _nextscene; }
	void setNextScene(Scene* nextscene) { _nextscene = nextscene; }

	DirectX::SimpleMath::Matrix _view;
	DirectX::SimpleMath::Matrix _proj;

};

