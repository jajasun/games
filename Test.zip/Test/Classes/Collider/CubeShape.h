// ============================================================================
//! @file	CubeShape
//! @brief  �L���[�u�̌`��N���X�̃w�b�_�[
//! @date   2016/11/1
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once
#include "Shape.h"
#include <SimpleMath.h>
// ============================================================================
//! @class	CubeShape
//! @brief	�L���[�u�N���X
// ============================================================================
class CubeShape :
	public Shape
{
private:
	// �ʒu
	DirectX::SimpleMath::Vector3 _position;
	// ���a
	DirectX::SimpleMath::Vector3 _radius;
	// ��]�p�x
	DirectX::SimpleMath::Vector3 _rotation;

public:
	CubeShape();
	~CubeShape();
	SHAPE_TYPE getShapeType() const override { return SHAPE_CUBE; }
};

