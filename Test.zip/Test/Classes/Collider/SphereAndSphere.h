// ============================================================================
//! @file   
//! @brief  
//! @date   
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once
#include "Collider.h"
// ============================================================================
//! @class	SphereAndSphere
//! @brief	���Ƌ��̓����蔻��
// ============================================================================
class SphereAndSphere :
	public Collider
{
public:
	SphereAndSphere();
	~SphereAndSphere();
	bool Hit(const Shape& s1, const Shape& s2) override;
	bool Hit(GameObject* o1, GameObject* o2) override;
};

