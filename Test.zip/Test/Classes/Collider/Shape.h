// ============================================================================
//! @file	Shape.h   
//! @brief	�`���\�����ۃN���X�w�b�_�[
//! @date   
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once

// ============================================================================
//! @class	Shape
//! @brief	�`��N���X
// ============================================================================
class Shape
{
public:
	// �`��^�C�v
	enum SHAPE_TYPE
	{
		SHAPE_SPHERE,
		SHAPE_CUBE,
		SHAPE_SEGMENT,
		SHAPE_CAPSULE,

		SHAPE_NUM
	};
	Shape();
	virtual ~Shape();
	virtual SHAPE_TYPE getShapeType() const = 0;
};

