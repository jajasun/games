// ============================================================================
//! @file   CapsuleShape
//! @brief  �J�v�Z���N���X
//! @date   2016/11/02
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once
#include "Shape.h"
#include "SegmentShape.h"

// ============================================================================
//! @class	CapsuleShape
//! @brief	�J�v�Z��
// ============================================================================
class CapsuleShape :
	public Shape
{
private:
	// �c
	SegmentShape _segment;
	// ���a
	float _radius;
public:
	CapsuleShape();
	~CapsuleShape();
};

