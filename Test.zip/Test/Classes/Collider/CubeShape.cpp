#include "CubeShape.h"



CubeShape::CubeShape()
{
}


CubeShape::~CubeShape()
{
}
