// ============================================================================
//! @file   SegmentShape
//! @brief	�����N���X�̃w�b�_�[
//! @date   2016/11/02
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once
#include "Shape.h"
#include <SimpleMath.h>
// ============================================================================
//! @class	SegmentShape
//! @brief	�����N���X
// ============================================================================
class SegmentShape :
	public Shape
{
public:
	// �ϐ�
	// �n�_�ƏI�_
	DirectX::SimpleMath::Vector3 _start;
	DirectX::SimpleMath::Vector3 _end;

public:
	// �֐�
	SegmentShape();
	~SegmentShape();
	SHAPE_TYPE getShapeType() const override { return SHAPE_SEGMENT; }
};

