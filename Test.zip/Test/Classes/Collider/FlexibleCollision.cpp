// ============================================================================
//! @file   
//! @brief  
//! @date   
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#include "FlexibleCollision.h"
#include "SphereAndSphere.h"
#include "../GameObject/GameObject.h"
// ============================================================================
//! @brief �R���X�g���N�^
// ============================================================================
FlexibleCollision::FlexibleCollision()
{
	_colTable[Shape::SHAPE_SPHERE][Shape::SHAPE_SPHERE] = new SphereAndSphere();
	_colTable[Shape::SHAPE_CAPSULE][Shape::SHAPE_CAPSULE] = new SphereAndSphere();
	_colTable[Shape::SHAPE_CUBE][Shape::SHAPE_CUBE] = new SphereAndSphere();
	_colTable[Shape::SHAPE_SEGMENT][Shape::SHAPE_SEGMENT] = new SphereAndSphere();

}

// ============================================================================
//! @brief �f�X�g���N�^
// ============================================================================
FlexibleCollision::~FlexibleCollision()
{
	for (int i = 0; i < Shape::SHAPE_NUM; i++)
	{
		for (int j = 0; j < Shape::SHAPE_NUM;j++)
		{
			delete _colTable[i][j];
		}
	}
}
// ============================================================================
//! @brief �Փ˔���
//! @param[in] s1	�`��P
//! @param[in] s2	�`��Q
//! @return true false
// ============================================================================
bool FlexibleCollision::Hit(const Shape & s1, const Shape & s2)
{
	return _colTable[s1.getShapeType()][s2.getShapeType()]->Hit(s1, s2);
}
// ============================================================================
//! @brief �Փ˔���
//! @param[in] o1	�I�u�W�F�N�g�P
//! @param[in] o2	�I�u�W�F�N�g�Q
//! @return true false
// ============================================================================
bool FlexibleCollision::Hit(GameObject * o1, GameObject * o2)
{
	return 0;//_colTable[o1->getShape()->getShapeType()][o2->getShape()->getShapeType()]->Hit(o1, o2);
}
