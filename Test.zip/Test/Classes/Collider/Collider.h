// ============================================================================
//! @file   Collider
//! @brief	�Փ˔���N���X
//! @date   2016/11/02
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once
#include <SimpleMath.h>
// ============================================================================
//! @brief	�N���X�錾
// ============================================================================
class Shape;
class GameObject;
// ============================================================================
//! @class	Collider
//! @brief	�Փ˔�����ԐړI�ɍs���N���X
// ============================================================================
class Collider
{
public:
	Collider();
	~Collider();
	// �`��𒼐ڎQ�Ƃ���
	virtual bool Hit(const Shape& s1, const Shape& s2) = 0;
	// �I�u�W�F�N�g�̃A�h���X�𗘗p����
	virtual bool Hit(GameObject* o1, GameObject* o2) = 0;

	float VectorLength(const DirectX::SimpleMath::Vector3 & v)
	{
		return sqrtf(v.x*v.x + v.y*v.y + v.z*v.z);
	}
	float Distance3D(const DirectX::SimpleMath::Vector3 & p1, const DirectX::SimpleMath::Vector3 & p2)
	{
		return VectorLength(p1 - p2);
	}

	float VectorLengthSQ(const DirectX::SimpleMath::Vector3 & v)
	{
		return v.x*v.x + v.y*v.y + v.z*v.z;
	}

	float DistanceSQ3D(const DirectX::SimpleMath::Vector3 & p1, const DirectX::SimpleMath::Vector3 & p2)
	{
		return VectorLengthSQ(p1 - p2);
	}



};

