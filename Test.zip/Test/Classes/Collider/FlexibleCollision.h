// ============================================================================
//! @file   FlexibleCollision
//! @brief  
//! @date   
//! @author 
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once
#include "Collider.h"
#include "Shape.h"
// ============================================================================
//! @class	FlexibleCollision
//! @brief	�K�؂ȏՓ˂�I������N���X
// ============================================================================
class FlexibleCollision :
	public Collider
{
private:
	Collider* _colTable[Shape::SHAPE_NUM][Shape::SHAPE_NUM];
public:
	FlexibleCollision();
	virtual ~FlexibleCollision();

	bool Hit(const Shape& s1, const Shape& s2)  override;
	bool Hit(GameObject* o1, GameObject* o2) override;

};

