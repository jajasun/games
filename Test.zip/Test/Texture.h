// ============================================================================
//! @file   Texture.h
//! @brief  �e�N�X�`���֘A�̃w�b�_�t�@�C��
//! @date   2016-04-18
//! @author  
//  Copyright (C) 2016  . All rights reserved.
// ============================================================================
#pragma once

#include <d3d11.h>
#include <SimpleMath.h>

// ============================================================================
//! @brief �e�N�X�`���N���X
// ============================================================================
class Texture 
{
public:
	Texture(const wchar_t* file_path);
	~Texture();

	void Draw(const DirectX::SimpleMath::Vector2& position) const;

	void Draw(const DirectX::SimpleMath::Vector2& position, float angle) const;

	void Draw(const DirectX::SimpleMath::Vector2& position, float angle, float scale) const;

	void Draw(const DirectX::SimpleMath::Vector2& position, float angle,
		const DirectX::SimpleMath::Vector2& scale) const;

	void Draw(const DirectX::SimpleMath::Vector2& position, float angle,
		const DirectX::SimpleMath::Vector2& origine,
		const DirectX::SimpleMath::Vector2& scale) const;


	void Draw(const DirectX::SimpleMath::Vector2& position,
		const DirectX::SimpleMath::Vector2& src_position,
		const DirectX::SimpleMath::Vector2& src_size) const;

	void Draw(const DirectX::SimpleMath::Vector2& position,
		float angle, const DirectX::SimpleMath::Vector2& origine, float scale) const;

	void Draw(const DirectX::SimpleMath::Vector2& position,
		const DirectX::SimpleMath::Vector2& src_position,
		const DirectX::SimpleMath::Vector2& src_size,
		float angle, float scale) const;

	//DirectX::SimpleMath::Vector2 center() const { return center_; }
	//int width() const { return desc_.Width; }
	//int height() const { return desc_.Height; }
	ID3D11ShaderResourceView* texture_;

private:
	ID3D11Resource* resource_;
	D3D11_TEXTURE2D_DESC desc_;
	DirectX::SimpleMath::Vector2 center_;
};
